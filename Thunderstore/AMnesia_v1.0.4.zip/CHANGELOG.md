| `Version` | `Update Notes`                                                                                                             |
|-----------|----------------------------------------------------------------------------------------------------------------------------|
| 1.0.4     | - Update for Bog Witch                                                                                                     |
| 1.0.3     | - Update for latest Valheim 0.217.46                                                                                       |
| 1.0.2     | - Update for latest Valheim                                                                                                |
| 1.0.1     | - Also remove the day from all pins on the map. This is retroactive, meaning it will remove old ones and prevent new ones. |
| 1.0.0     | - Initial Release                                                                                                          |
